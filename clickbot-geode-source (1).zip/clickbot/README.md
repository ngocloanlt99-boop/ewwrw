# Click Bot (Geode, GD 2.2081)

Nhan **V** de mo menu. Menu chi co 1 chuc nang: Click Bot.

1. Bat **Record**, choi level tu dau den luc thang -> macro tu luu.
2. Bat **Play**, vao lai level -> bot chay lai dung cac cu click.

## Build
1. Cai Geode SDK + Geode CLI (https://docs.geode-sdk.org/getting-started/)
2. `geode build` trong thu muc nay
3. File `o.clickbot.geode` nam trong thu muc build -> chep vao `geode/mods`

## Build tren GitHub (khong can cai gi tren may)
1. Tao repo GitHub moi, upload toan bo thu muc nay len (giu nguyen `.github/workflows/build.yml`).
2. Vao tab **Actions** -> chay "Build Geode Mod" (hoac no tu chay sau khi push).
3. Khi xong, mo lan chay do -> muc **Artifacts** -> tai "Build Output" -> giai nen se co `o.clickbot.geode`.
