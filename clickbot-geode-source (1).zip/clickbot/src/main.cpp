#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/CCKeyboardDispatcher.hpp>
#include <fstream>
#include <vector>
#include <cstdint>

using namespace geode::prelude;

// ---------------------------------------------------------------- bot state
enum class BotMode { Off, Record, Play };

struct Action {
	uint32_t frame;   // buoc vat ly (physics step) khi nhan/tha
	uint8_t  button;
	uint8_t  down;
	uint8_t  player1;
};

namespace bot {
	inline BotMode mode = BotMode::Off;
	inline std::vector<Action> macro;
	inline size_t cursor = 0;
	inline bool injecting = false;

	inline std::filesystem::path macroPath(GJGameLevel* level) {
		std::string name = level->m_levelName;
		for (auto& c : name) if (!isalnum(static_cast<unsigned char>(c))) c = '_';
		return Mod::get()->getSaveDir() /
			fmt::format("{}_{}.macro", static_cast<int>(level->m_levelID), name);
	}

	inline void save(GJGameLevel* level) {
		std::ofstream f(macroPath(level), std::ios::binary);
		uint32_t n = static_cast<uint32_t>(macro.size());
		f.write(reinterpret_cast<char*>(&n), sizeof(n));
		for (auto& a : macro) {
			f.write(reinterpret_cast<char*>(&a.frame), sizeof(a.frame));
			f.write(reinterpret_cast<char*>(&a.button), 1);
			f.write(reinterpret_cast<char*>(&a.down), 1);
			f.write(reinterpret_cast<char*>(&a.player1), 1);
		}
	}

	inline bool load(GJGameLevel* level) {
		std::ifstream f(macroPath(level), std::ios::binary);
		if (!f) return false;
		uint32_t n = 0;
		f.read(reinterpret_cast<char*>(&n), sizeof(n));
		macro.clear();
		for (uint32_t i = 0; i < n && f; ++i) {
			Action a{};
			f.read(reinterpret_cast<char*>(&a.frame), sizeof(a.frame));
			f.read(reinterpret_cast<char*>(&a.button), 1);
			f.read(reinterpret_cast<char*>(&a.down), 1);
			f.read(reinterpret_cast<char*>(&a.player1), 1);
			macro.push_back(a);
		}
		return !macro.empty();
	}
}

// ---------------------------------------------------------------- hooks
class $modify(BotGameLayer, GJBaseGameLayer) {
	void processCommands(float dt) {
		auto pl = PlayLayer::get();
		if (pl && bot::mode == BotMode::Play) {
			auto step = static_cast<uint32_t>(m_gameState.m_currentProgress);
			while (bot::cursor < bot::macro.size() && bot::macro[bot::cursor].frame <= step) {
				auto& a = bot::macro[bot::cursor++];
				bot::injecting = true;
				GJBaseGameLayer::handleButton(a.down != 0, a.button, a.player1 != 0);
				bot::injecting = false;
			}
		}
		GJBaseGameLayer::processCommands(dt);
	}

	void handleButton(bool down, int button, bool isPlayer1) {
		if (PlayLayer::get()) {
			if (bot::mode == BotMode::Play && !bot::injecting) return; // chan input tay khi bot dang chay
			if (bot::mode == BotMode::Record && !bot::injecting) {
				bot::macro.push_back({
					static_cast<uint32_t>(m_gameState.m_currentProgress),
					static_cast<uint8_t>(button),
					static_cast<uint8_t>(down),
					static_cast<uint8_t>(isPlayer1)
				});
			}
		}
		GJBaseGameLayer::handleButton(down, button, isPlayer1);
	}
};

class $modify(BotPlayLayer, PlayLayer) {
	void setupHasCompleted() {
		PlayLayer::setupHasCompleted();
		if (bot::mode == BotMode::Play) {
			if (!bot::load(m_level)) {
				bot::mode = BotMode::Off;
				Notification::create("Chua co macro cho level nay!", NotificationIcon::Error)->show();
			}
		}
	}

	void resetLevel() {
		PlayLayer::resetLevel();
		bot::cursor = 0;
		if (bot::mode == BotMode::Record) bot::macro.clear(); // ghi lai tu dau moi lan thu
	}

	void levelComplete() {
		if (bot::mode == BotMode::Record && !bot::macro.empty()) {
			bot::save(m_level);
			Notification::create("Da luu macro!", NotificationIcon::Success)->show();
		}
		PlayLayer::levelComplete();
	}
};

// ---------------------------------------------------------------- menu
class BotMenu : public CCLayerColor {
	CCMenuItemToggler* m_record = nullptr;
	CCMenuItemToggler* m_play = nullptr;
	inline static BotMenu* s_instance = nullptr;

public:
	static void toggle() {
		if (s_instance) { s_instance->close(); return; }
		auto scene = CCDirector::get()->getRunningScene();
		if (!scene) return;
		auto m = new BotMenu();
		if (m && m->init()) {
			m->autorelease();
			s_instance = m;
			scene->addChild(m, 99999);
		} else {
			CC_SAFE_DELETE(m);
		}
	}

	bool init() override {
		if (!CCLayerColor::initWithColor({0, 0, 0, 150})) return false;
		this->setTouchEnabled(true);
		this->setKeypadEnabled(true);

		auto win = CCDirector::get()->getWinSize();

		auto panel = CCScale9Sprite::create("GJ_square01.png");
		panel->setContentSize({300.f, 190.f});
		panel->setPosition(win / 2);
		this->addChild(panel);

		auto title = CCLabelBMFont::create("Click Bot", "bigFont.fnt");
		title->setScale(0.8f);
		title->setPosition({win.width / 2, win.height / 2 + 70.f});
		this->addChild(title);

		auto menu = CCMenu::create();
		menu->setPosition({0, 0});
		this->addChild(menu);

		// Ghi macro
		m_record = CCMenuItemToggler::createWithStandardSprites(this, menu_selector(BotMenu::onRecord), 0.8f);
		m_record->setPosition({win.width / 2 - 100.f, win.height / 2 + 25.f});
		m_record->toggle(bot::mode == BotMode::Record);
		menu->addChild(m_record);
		auto l1 = CCLabelBMFont::create("Ghi (Record)", "bigFont.fnt");
		l1->setScale(0.5f);
		l1->setAnchorPoint({0, 0.5f});
		l1->setPosition({win.width / 2 - 75.f, win.height / 2 + 25.f});
		this->addChild(l1);

		// Bot choi
		m_play = CCMenuItemToggler::createWithStandardSprites(this, menu_selector(BotMenu::onPlay), 0.8f);
		m_play->setPosition({win.width / 2 - 100.f, win.height / 2 - 15.f});
		m_play->toggle(bot::mode == BotMode::Play);
		menu->addChild(m_play);
		auto l2 = CCLabelBMFont::create("Bot choi (Play)", "bigFont.fnt");
		l2->setScale(0.5f);
		l2->setAnchorPoint({0, 0.5f});
		l2->setPosition({win.width / 2 - 75.f, win.height / 2 - 15.f});
		this->addChild(l2);

		auto hint = CCLabelBMFont::create("Ghi 1 lan thang level -> bat Play de bot chay lai", "chatFont.fnt");
		hint->setScale(0.55f);
		hint->setPosition({win.width / 2, win.height / 2 - 55.f});
		this->addChild(hint);

		auto closeSpr = ButtonSprite::create("Dong");
		auto closeBtn = CCMenuItemSpriteExtra::create(closeSpr, this, menu_selector(BotMenu::onClose));
		closeBtn->setPosition({win.width / 2, win.height / 2 - 78.f});
		menu->addChild(closeBtn);

		return true;
	}

	void registerWithTouchDispatcher() override {
		CCTouchDispatcher::get()->addTargetedDelegate(this, -500, true);
	}
	bool ccTouchBegan(CCTouch*, CCEvent*) override { return true; }
	void keyBackClicked() override { this->close(); }

	void onRecord(CCObject*) {
		bool on = !m_record->isToggled(); // callback chay truoc khi nut doi trang thai
		if (on) {
			m_play->toggle(false);
			bot::mode = BotMode::Record;
			bot::macro.clear();
			Notification::create("Record: choi tu dau level den khi thang", NotificationIcon::Info)->show();
		} else {
			bot::mode = BotMode::Off;
		}
	}

	void onPlay(CCObject*) {
		bool on = !m_play->isToggled();
		if (on) {
			m_record->toggle(false);
			bot::mode = BotMode::Play;
			bot::cursor = 0;
			Notification::create("Play: vao level de bot tu choi", NotificationIcon::Info)->show();
		} else {
			bot::mode = BotMode::Off;
		}
	}

	void onClose(CCObject*) { this->close(); }

	void close() {
		s_instance = nullptr;
		this->removeFromParentAndCleanup(true);
	}
};

class $modify(BotKeys, CCKeyboardDispatcher) {
	bool dispatchKeyboardMSG(enumKeyCodes key, bool down, bool repeat, double timestamp) {
		if (down && !repeat && key == KEY_V) {
			// khong chiem phim V khi dang go chu vao o text
			if (!CCIMEDispatcher::sharedDispatcher()->hasDelegate()) {
				BotMenu::toggle();
				return true;
			}
		}
		return CCKeyboardDispatcher::dispatchKeyboardMSG(key, down, repeat, timestamp);
	}
};
