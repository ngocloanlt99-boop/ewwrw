# Click Bot (Geode, GD 2.2081)

Nhan **V** de mo menu. Menu chi co 1 chuc nang: Click Bot.

1. Bat **Record**, choi level tu dau den luc thang -> macro tu luu.
2. Bat **Play**, vao lai level -> bot chay lai dung cac cu click.

## Build
1. Cai Geode SDK + Geode CLI (https://docs.geode-sdk.org/getting-started/)
2. `geode build` trong thu muc nay
3. File `o.clickbot.geode` nam trong thu muc build -> chep vao `geode/mods`
